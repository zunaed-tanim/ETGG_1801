# ------------------------------ STEP 02 --------------------------------

# Course ID.Section      : ETGG1801.90
# First Name & Last Name : Md Zunaed, Tanim
# Lab Number & Name      : Lab 01 - Hello World
# Date created           : 02 September, 2020

# *********************************************************
# importing math library to calculate hypotenuse in step 04
import math
# *********************************************************

# ------------------------------ STEP 03 ---------------------------------

# Creating variables
"""
* firstName - string
* lastName - string
* opposite - float
* adjacent - integer
"""
firstName = "Md Zunaed"
lastName = "Tanim"
opposite = float(input("Please enter a number value for opposite: "))
adjacent = int(input("Please enter a number value for adjacent: "))


# ------------------------------ STEP 04 ---------------------------------

# Printing firstName and lastName to the screen
print("Lab01 created by:", firstName, lastName)

# Printing firstName and lastName to the screen, using the end parameter, with two print statements
print(firstName, end=" ")
print(lastName)

# Calculating the hypotenuse from opposite & adjacent
hypotenuse = math.hypot(opposite, adjacent)
print("The hypotenuse length is " + str(hypotenuse) + ", if the other sides are " + str(adjacent) + " and " + str(opposite))

input("Press enter to continue...")





